# Operating notes

## Evidence and provenance

- Base claims on retrieved sources or tool outputs only.
- Record DOI/PMID/accession/path/run ID, access date, confidence, and limitations for important claims.
- Separate established findings, incomplete evidence, conflicts, gaps, and agent assumptions.

## Tool use

- Tools must be registered with user-provided paths and example commands before job proposals.
- Never invent CLI flags or API parameters.
- Prefer a smoke test before large runs.
- Capture stdout/stderr/exit codes in `outputs/logs/` and link them from `provenance/`.

## Autonomy gates

See `configs/autonomy.yaml`. Default: prepare plans freely; seek approval for compute jobs, paid APIs, writes outside approved outputs, and destructive/external actions.

## Adding a use case

1. Add an entry to `use_cases/catalog.yaml`.
2. Create `use_cases/<id>/` with intake, research brief, and workflow files when active.
3. Point `configs/session.yaml` at the active use case.

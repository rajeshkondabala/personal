# Tool registry schema

Each entry in `registry.yaml` must follow:

| Field | Required | Description |
|---|---|---|
| `tool_name` | yes | Stable short name |
| `category` | yes | `docking \| MD \| quantum \| ADMET \| retrosynthesis \| literature \| database \| analysis` |
| `executable_or_endpoint` | yes* | Exact user-provided path, CLI, or API endpoint (`null` until provided) |
| `version` | no | Version string if known |
| `input_format` | yes* | Expected input format(s) |
| `output_format` | yes* | Expected output format(s) |
| `required_parameters` | yes | List of required args/params |
| `optional_parameters` | yes | List of optional args/params |
| `example_command` | recommended | Paste a real working example; do not invent flags |
| `known_limitations` | yes | Documented limits and failure modes |
| `validation_status` | yes | `missing \| untested \| smoke-tested \| validated` |
| `user_provided` | yes | `true` only when path/API came from the user |

\*Required before any job using that tool may be proposed for execution.

## Registration rules

1. Never invent executable paths, CLI flags, or API parameters.
2. If documentation is incomplete, ask for usage instructions or a sample command.
3. Smoke-test with the smallest non-destructive command before marking `smoke-tested`.
4. Record software version, hostname, and date in provenance when validating.
5. Secrets must not appear in this file; reference env var names only.

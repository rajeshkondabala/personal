# QID-Agent session intake

Copy and fill. Leave unknown fields as `null` rather than guessing.

## 1. Scientific objective
- First use case id (from `use_cases/catalog.yaml`):
- Primary question:
- Success criteria:

## 2. Organism / context
- Organism:
- Biological system:
- Disease or application context:
- Cell type / tissue / pathway / environment:
- Species restrictions:

## 3. Inputs on hand
- UniProt / gene / PDB / sequence / structure paths:
- Compound libraries (SMILES/SDF/MOL2) and database IDs:
- Known actives/inactives:
- Prior docking / MD / QM / ADMET / notes paths:
- Data location convention:

## 4. Tools & resources
For each tool (docking, HBT, MD, dispersion-corrected MD, quantum, ADMET, retrosynthesis, literature):
- Name:
- Executable path or API:
- Input/output format:
- Example command:
- Version (if known):

Compute:
- CPU cores / RAM / GPU / storage:
- Max runtime per job / max concurrent jobs:
- Cloud/API budget / cost ceiling:

## 5. Deliverable
- Primary deliverable(s):
- Output format(s):
- Depth: quick scan | standard report | comprehensive review

## 6. Constraints
- Deadline / cost / safety / regulatory / IP / privacy / compute caps:
- Tools that must not be used:

## 7. Autonomy
- Mode: propose_only | execute_after_approval | autonomous_within_limits
- Hard limits (tool calls, elapsed time, compute cost, confidence floor):

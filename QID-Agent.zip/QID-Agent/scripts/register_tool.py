#!/usr/bin/env python3
"""Register or update a tool entry from user-provided fields.

Does not invent paths or flags. Requires --executable and preferably --example-command.
"""

from __future__ import annotations

import argparse
import datetime as dt
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML required (pip install pyyaml)", file=sys.stderr)
    sys.exit(1)

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "tool_registry" / "registry.yaml"


def main() -> int:
    p = argparse.ArgumentParser(description="Register a QID tool (user-provided only)")
    p.add_argument("--tool-name", required=True)
    p.add_argument(
        "--category",
        required=True,
        choices=[
            "docking",
            "MD",
            "quantum",
            "ADMET",
            "retrosynthesis",
            "literature",
            "database",
            "analysis",
        ],
    )
    p.add_argument("--executable", required=True, help="Exact path, CLI, or API endpoint")
    p.add_argument("--version", default=None)
    p.add_argument("--input-format", default=None)
    p.add_argument("--output-format", default=None)
    p.add_argument("--example-command", default=None)
    p.add_argument("--validation-status", default="untested",
                   choices=["untested", "smoke-tested", "validated", "missing"])
    args = p.parse_args()

    data = yaml.safe_load(REGISTRY.read_text(encoding="utf-8")) or {}
    tools = data.setdefault("tool_registry", [])

    entry = None
    for t in tools:
        if t.get("tool_name") == args.tool_name:
            entry = t
            break
    if entry is None:
        entry = {"tool_name": args.tool_name}
        tools.append(entry)

    entry.update(
        {
            "category": args.category,
            "executable_or_endpoint": args.executable,
            "version": args.version,
            "input_format": args.input_format,
            "output_format": args.output_format,
            "example_command": args.example_command,
            "required_parameters": entry.get("required_parameters") or [],
            "optional_parameters": entry.get("optional_parameters") or [],
            "known_limitations": entry.get("known_limitations") or [],
            "validation_status": args.validation_status,
            "user_provided": True,
        }
    )
    data["updated_utc"] = dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

    REGISTRY.write_text(
        yaml.safe_dump(data, sort_keys=False, default_flow_style=False),
        encoding="utf-8",
    )
    print(f"registered tool_name={args.tool_name} path={args.executable}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Validate QID-Agent scaffolding layout and registry completeness."""

from __future__ import annotations

import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_DIRS = [
    "configs",
    "tool_registry",
    "use_cases",
    "templates/research_brief",
    "templates/workflow",
    "templates/recommendation",
    "templates/provenance",
    "inputs/structures",
    "inputs/sequences",
    "inputs/compounds",
    "inputs/datasets",
    "inputs/literature",
    "outputs/runs",
    "outputs/reports",
    "outputs/figures",
    "outputs/logs",
    "workflows",
    "scripts",
    "provenance",
    "docs",
]

REQUIRED_FILES = [
    "configs/session.yaml",
    "configs/autonomy.yaml",
    "tool_registry/registry.yaml",
    "tool_registry/SCHEMA.md",
    "use_cases/catalog.yaml",
    "templates/research_brief/research_brief.yaml",
    "templates/workflow/workflow.yaml",
    "templates/recommendation/recommendation.yaml",
    "templates/provenance/provenance_record.yaml",
    "templates/session_intake.md",
]


def main() -> int:
    errors: list[str] = []
    warnings: list[str] = []

    for rel in REQUIRED_DIRS:
        if not (ROOT / rel).is_dir():
            errors.append(f"missing directory: {rel}")

    for rel in REQUIRED_FILES:
        if not (ROOT / rel).is_file():
            errors.append(f"missing file: {rel}")

    registry_path = ROOT / "tool_registry" / "registry.yaml"
    if registry_path.is_file() and yaml is not None:
        data = yaml.safe_load(registry_path.read_text(encoding="utf-8")) or {}
        tools = data.get("tool_registry") or []
        registered = 0
        for tool in tools:
            name = tool.get("tool_name", "<unnamed>")
            status = tool.get("validation_status")
            endpoint = tool.get("executable_or_endpoint")
            if endpoint and tool.get("user_provided"):
                registered += 1
            if status == "missing":
                warnings.append(f"tool unregistered: {name}")
            if endpoint and not tool.get("example_command"):
                warnings.append(f"tool lacks example_command: {name}")
        print(f"tools_total={len(tools)} tools_user_registered={registered}")
    elif registry_path.is_file() and yaml is None:
        warnings.append("PyYAML not installed; skipped registry parse")

    for msg in warnings:
        print(f"WARNING: {msg}")
    for msg in errors:
        print(f"ERROR: {msg}")

    if errors:
        print("scaffold_status=FAILED")
        return 1

    print("scaffold_status=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())

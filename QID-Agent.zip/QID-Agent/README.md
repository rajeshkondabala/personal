# QID-Agent

Quantum-Informed Discovery autonomous research agent workspace.

This repository scaffolds research briefs, tool registration, provenance, and executable workflows. It does **not** invent scientific results, citations, identifiers, or tool outputs.

## Quick start

1. Fill `templates/session_intake.md` (or update `configs/session.yaml`).
2. Register tools in `tool_registry/registry.yaml` with **exact** paths and example commands.
3. Validate scaffolding:

```bash
python3 scripts/validate_scaffold.py
```

4. Confirm autonomy mode in `configs/autonomy.yaml` (default: `execute_after_approval`).
5. Select a use case from `use_cases/catalog.yaml` and request a Research Brief.

## Layout

| Path | Purpose |
|---|---|
| `configs/` | Session and autonomy policy |
| `tool_registry/` | User-provided tool definitions |
| `use_cases/` | Portfolio catalog |
| `templates/` | Research brief, workflow, recommendation, provenance |
| `inputs/` | Structures, sequences, compounds, datasets, literature |
| `outputs/` | Runs, reports, figures, logs |
| `workflows/` | Executable workflow definitions |
| `provenance/` | Provenance records for claims and runs |
| `scripts/` | Validation and helper utilities |
| `docs/` | Operating notes |

## Safety and autonomy

- Evidence first; provenance always; no fabricated data.
- Compute jobs (docking/MD/QM/ADMET/retrosynthesis) require approval.
- Do not assist with weapons, toxins, illicit drugs, or operational synthesis of highly hazardous agents.
- Secrets stay in environment variables — never in registry files.

## Status

Scaffolding complete. Scientific tools are **unregistered** until you provide paths and example commands.

# BCL-xL senolytic BH3-mimetic — plan-only report

**Session:** qid-session-0001  
**Use case:** `longevity_senolytic_bclxl`  
**Mode:** `execute_after_approval` (plan-only compute)  
**Date:** 2026-11-16  
**Status:** Assumptions applied after user said “go ahead”; confirm before compute.

---

## 1. Executive summary

Human BCL-xL (UniProt **Q07817**, gene **BCL2L1**) is a well-supported BH3-mimetic / senolytic target. Structural templates (**PDB 2YXJ** with ABT-737; apo **1R2D**) and a reference chemotype (**navitoclax**, PubChem **CID 24978538**) are resolved from public databases. No compound library or ADMET/retrosynthesis/quantum tools are available yet, so a **ranked shortlist cannot be produced honestly**. Local docking/MD binaries were **discovered** (Vina, GNINA, GROMACS) but are **not registered** until you confirm. `/usr/bin/orca` is the **GNOME screen reader**, not quantum ORCA.

**Recommended next action:** Confirm assumptions → approve tool registration → approve download of 2YXJ + navitoclax → approve a **single-ligand redock pilot**.

---

## 2. Assumptions (agent)

| Assumption | Value | Confidence |
|---|---|---|
| use_case_id | longevity_senolytic_bclxl | medium (inferred from “go ahead”) |
| Organism | Homo sapiens | medium |
| Target | BCL-xL / BCL2L1 | medium |
| Primary question | Prioritize SM inhibitors for experimental validation | medium |
| Shortlist N | 10 | low–medium |
| Scope | human-only; no clinical recommendations | medium |
| Compute | plan-only until approval | high |

---

## 3. Entity resolution

| Entity | Resolved ID | Notes | Source |
|---|---|---|---|
| Protein | Q07817 (B2CL1_HUMAN) | 233 aa; Swiss-Prot | UniProt REST 2026-11-16 |
| Gene | BCL2L1; GeneID 598; HGNC:992 | | UniProt cross-refs |
| Apo structure | PDB 1R2D | 1.95 Å X-ray | RCSB |
| Holo structure (preferred) | PDB 2YXJ | Bcl-xL + ABT-737, 2.2 Å | RCSB; DOI 10.1038/sj.cdd.4402178 |
| Reference ligand | CID 24978538 navitoclax | InChIKey JLYAXFNOILIKPP-KXQOOQHDSA-N | PubChem PUG REST |

---

## 4. Evidence review (condensed)

**Established**

- BH3 mimetics inhibit anti-apoptotic BCL-2 family proteins; navitoclax is a major senolytic BH3 mimetic (Open Biology DOI:10.1098/rsob.220171; TiPS DOI:10.1016/j.tips.2024.01.002).
- BCL-xL inhibition is frequently required for senolysis; platelet BCL-xL dependence drives thrombocytopenia risk (PMC7913597; Cancer Res BCL-xL targeting review).
- Rich structural coverage: UniProt lists 100+ PDB cross-references for Q07817.

**Incomplete / conflicting**

- Senolytic efficacy is cell-type and context dependent; not all senescent cells respond to navitoclax.
- Selective BCL-xL and PROTAC strategies are promising but not evaluated here.

**Gaps**

- No local library, docking results, ADMET, or assay model.

Full structured evidence: `use_cases/longevity_senolytic_bclxl/evidence_review.yaml`.

---

## 5. Hypotheses (falsifiable)

| ID | Hypothesis | Test | Priority |
|---|---|---|---|
| H1 | BH3-groove binders resembling ABT-737/navitoclax chemotypes will redock into 2YXJ with low RMSD to crystal pose | Pilot redock | high |
| H2 | Selectivity vs BCL-2/MCL-1 and platelet risk will limit clinical-like utility of dual inhibitors | Literature + future selectivity docking (needs structures) | high |
| H3 | A focused ChEMBL BCL-xL set will enrich docking scores vs decoys | Small enrichment pilot after library definition | medium |

---

## 6. Workflow status

See `workflows/longevity_senolytic_bclxl_plan_only.yaml`.

| Step | Status |
|---|---|
| Evidence + IDs | done |
| Tool discovery | done (pending registration) |
| Download structures/ligands | not started (needs approval) |
| Docking/MD/ADMET | blocked |
| Ranked N=10 CSV | blocked |

---

## 7. Tool registry (updated 2026-11-16)

**User-registered**

| Tool | Binding | Status |
|---|---|---|
| Prep | **Meeko 0.7.1** (`conda activate page`; `mk_prepare_ligand.py` / `mk_prepare_receptor.py`) | smoke-tested (`--help`) |
| Quantum | **GPUPySCF** (`gpu4pyscf` in conda env `page`; PySCF 2.14.0) | untested — CUDA import failed this session |
| ADMET | **ADMET-AI** https://github.com/swansonk14/admet_ai | missing install (`admet_ai` not importable) |
| Retrosynthesis | `/home/chemthings/Retrosynthesis` (RetroCharge / retrosyn 0.1.0) | path verified; API not started |

**Replaced / rejected:** MGLTools → Meeko; ORCA → GPUPySCF (`/usr/bin/orca` is GNOME screen reader).

**Deferred (user will link later):** docking (Vina/GNINA discovered), MD (GROMACS discovered), HBT, dispersion-corrected MD.

Canonical file: `tool_registry/registry.yaml`.

---

## 8. Decision memo

**Do now (no compute):** confirm BCL-xL assumptions; optionally `pip install admet-ai` in a dedicated env; verify CUDA for GPUPySCF.  
**Approve next:** register a docking engine; fetch 2YXJ + navitoclax; Meeko prep + single-ligand redock pilot.  
**Do not:** claim candidate potency, invent a shortlist, start Retrosynthesis API, or run QM/ADMET jobs without approval.

---

## 9. Provenance

- UniProt Q07817 JSON retrieved 2026-11-16  
- RCSB 1R2D, 2YXJ metadata retrieved 2026-11-16  
- PubChem navitoclax properties retrieved 2026-11-16  
- Literature via web search / publisher pages (DOIs above)  
- Local binary probes under `/usr/bin` and `/home/apps`

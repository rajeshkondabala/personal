~/pdbfixer_files/pdbfixer --help

cd /home/chemthings/pdbfixer_files
curl -L -o 6WFJ.pdb https://files.rcsb.org/download/6WFJ.pdb
curl -L -o 6WFJ.cif https://files.rcsb.org/download/6WFJ.cif

./pdbfixer --input 6WFJ.pdb --output 6WFJ_Fixer.pdb
./pdbfixer --input 6WFJ.cif --output 6WFJ_cif_Fixer.pdb

####Heavy atoms only, at a chosen pH:
./pdbfixer --input 6WFJ.pdb --output 6WFJ_heavy.pdb --no-hydrogens
./pdbfixer --input 6WFJ.pdb --output 6WFJ_ph74.pdb --ph 7.4

#######Check that waters and ligands are still there. The two lists should match.
echo "BEFORE"
grep '^HETATM' 6WFJ.pdb | awk '{print substr($0,18,3)}' | sort | uniq -c

echo "AFTER"
grep '^HETATM' 6WFJ_Fixer.pdb | awk '{print substr($0,18,3)}' | sort | uniq -c

"""Command line: pdbfixer --input structure.pdb --output structure_Fixer.pdb"""

from __future__ import annotations

import argparse
import sys

from pdb_structure_fixer.fix import fix_structure


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pdbfixer",
        description=(
            "Fill missing residues and missing atoms in a PDB or mmCIF structure. "
            "Crystallographic waters and co-crystal ligands are kept."
        ),
        epilog=(
            "examples:\n"
            "  pdbfixer --input 6WFJ.pdb --output 6WFJ_Fixer.pdb\n"
            "  pdbfixer --input 6WFJ.cif --output 6WFJ_Fixer.pdb\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--input",
        required=True,
        metavar="FILE",
        help="Input structure (.pdb, .ent, .cif, .mmcif, or .pdbx)",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="FILE",
        help="Output PDB file, for example 6WFJ_Fixer.pdb",
    )
    parser.add_argument(
        "--ph",
        type=float,
        default=7.0,
        help="pH used when adding missing hydrogens (default: 7.0)",
    )
    parser.add_argument(
        "--no-hydrogens",
        action="store_true",
        help="Add missing residues and heavy atoms only",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed for placement of newly built atoms",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        result = fix_structure(
            args.input,
            args.output,
            ph=args.ph,
            add_hydrogens=not args.no_hydrogens,
            seed=args.seed,
        )
    except (FileNotFoundError, ValueError, RuntimeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    print(f"Input: {result.input_path}")
    print(
        f"Missing residues added: {result.missing_residues} "
        f"at {result.missing_residue_sites} site(s)"
    )
    print(
        f"Missing heavy atoms added: {result.missing_heavy_atoms} "
        f"(terminal atoms: {result.missing_terminal_atoms})"
    )
    if result.hydrogens_added:
        print(f"Hydrogens added at pH {result.ph}")
    elif result.hydrogen_warning:
        print(f"warning: {result.hydrogen_warning}", file=sys.stderr)
    else:
        print("Hydrogens: not requested")
    print(f"Waters kept: {result.waters_after} (started with {result.waters_before})")
    print(f"Ligands kept: {len(result.ligands_after)} (started with {len(result.ligands_before)})")
    if result.ligands_after:
        print("Ligands: " + ", ".join(result.ligands_after))
    print(f"Wrote {result.output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

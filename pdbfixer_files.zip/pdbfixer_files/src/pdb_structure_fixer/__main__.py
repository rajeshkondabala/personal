from pdb_structure_fixer.cli import main

raise SystemExit(main())

"""PDBFixer workflow that rebuilds missing polymer atoms and leaves heterogens in place."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

# OpenMM/PDBFixer standard polymer names, plus residues PDBFixer itself never treats as heterogens.
_PROTEIN = {
    "ALA", "ASN", "CYS", "GLU", "HIS", "LEU", "MET", "PRO", "THR", "TYR",
    "ARG", "ASP", "GLN", "GLY", "ILE", "LYS", "PHE", "SER", "TRP", "VAL",
}
_RNA = {"A", "G", "C", "U", "I"}
_DNA = {"DA", "DG", "DC", "DT", "DI"}
_POLYMER = _PROTEIN | _RNA | _DNA | {"N", "UNK"}
_WATER = {"HOH", "WAT", "H2O", "DOD", "TIP", "TIP3", "SOL", "OH2"}

_INPUT_SUFFIXES = {".pdb", ".ent", ".cif", ".mmcif", ".pdbx"}


@dataclass
class FixResult:
    """What was added, and which heterogens were still present afterward."""

    input_path: Path
    output_path: Path
    missing_residue_sites: int
    missing_residues: int
    missing_heavy_atoms: int
    missing_terminal_atoms: int
    hydrogens_added: bool
    ph: float | None
    waters_before: int
    waters_after: int
    ligands_before: tuple[str, ...] = field(default_factory=tuple)
    ligands_after: tuple[str, ...] = field(default_factory=tuple)
    hydrogen_warning: str | None = None


def fix_structure(
    input_path: str | Path,
    output_path: str | Path,
    *,
    ph: float = 7.0,
    add_hydrogens: bool = True,
    seed: int | None = None,
) -> FixResult:
    """Add missing residues and atoms. Waters and co-crystal ligands are not removed.

    Parameters
    ----------
    input_path
        PDB or PDBx/mmCIF file. Format is detected from the contents.
    output_path
        Destination PDB file.
    ph
        pH used to choose protonation states when hydrogens are added.
    add_hydrogens
        When True, missing hydrogens are added after heavy atoms.
    seed
        Optional seed forwarded to PDBFixer's atom placement.
    """
    from pdbfixer import PDBFixer
    from openmm.app import PDBFile

    source = Path(input_path).expanduser().resolve()
    destination = Path(output_path).expanduser().resolve()
    _validate_input(source)

    fixer = PDBFixer(filename=str(source))
    waters_before, ligands_before = _heterogen_inventory(fixer.topology)

    fixer.findMissingResidues()
    missing_residue_sites = len(fixer.missingResidues)
    missing_residues = sum(len(names) for names in fixer.missingResidues.values())

    fixer.findMissingAtoms()
    missing_heavy_atoms = sum(len(names) for names in fixer.missingAtoms.values())
    missing_terminal_atoms = sum(len(names) for names in fixer.missingTerminals.values())

    # addMissingAtoms inserts residues from missingResidues and heavy atoms from
    # missingAtoms / missingTerminals. It does not delete existing heterogens.
    fixer.addMissingAtoms(seed=seed)

    hydrogens_added = False
    hydrogen_warning = None
    if add_hydrogens:
        try:
            fixer.addMissingHydrogens(ph)
            hydrogens_added = True
        except Exception as exc:
            # Heavy-atom repair already succeeded. Keep waters and ligands and
            # still write that structure instead of discarding the repair.
            hydrogen_warning = (
                "Missing heavy atoms were added, but hydrogens could not be placed "
                f"({exc}). The output file does not contain the added hydrogens. "
                "Re-run with --no-hydrogens to skip this step."
            )

    waters_after, ligands_after = _heterogen_inventory(fixer.topology)
    _ensure_heterogens_kept(waters_before, waters_after, ligands_before, ligands_after)

    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8") as handle:
        handle.write(f"REMARK   1 PDBFIXER FROM: {source}\n")
        handle.write(
            "REMARK   1 MISSING RESIDUES AND ATOMS ADDED; "
            "CRYSTALLOGRAPHIC WATERS AND CO-CRYSTAL LIGANDS RETAINED\n"
        )
        PDBFile.writeFile(fixer.topology, fixer.positions, handle, keepIds=True)

    return FixResult(
        input_path=source,
        output_path=destination,
        missing_residue_sites=missing_residue_sites,
        missing_residues=missing_residues,
        missing_heavy_atoms=missing_heavy_atoms,
        missing_terminal_atoms=missing_terminal_atoms,
        hydrogens_added=hydrogens_added,
        ph=ph if hydrogens_added else None,
        waters_before=len(waters_before),
        waters_after=len(waters_after),
        ligands_before=ligands_before,
        ligands_after=ligands_after,
        hydrogen_warning=hydrogen_warning,
    )


def _validate_input(source: Path) -> None:
    if not source.is_file():
        raise FileNotFoundError(f"Input structure not found: {source}")
    if source.suffix.lower() not in _INPUT_SUFFIXES:
        allowed = ", ".join(sorted(_INPUT_SUFFIXES))
        raise ValueError(
            f"Unsupported input type '{source.suffix}'. Expected one of: {allowed}"
        )


def _heterogen_inventory(topology) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Return sorted water and ligand labels as (chain, resseq, icode, name)."""
    waters: list[str] = []
    ligands: list[str] = []
    for chain in topology.chains():
        for residue in chain.residues():
            label = _residue_label(chain.id, residue)
            if residue.name in _WATER:
                waters.append(label)
            elif residue.name not in _POLYMER:
                ligands.append(label)
    return tuple(sorted(waters)), tuple(sorted(ligands))


def _residue_label(chain_id: str, residue) -> str:
    icode = residue.insertionCode.strip()
    suffix = f"^{icode}" if icode else ""
    return f"{residue.name} {chain_id}:{residue.id}{suffix}"


def _ensure_heterogens_kept(
    waters_before: tuple[str, ...],
    waters_after: tuple[str, ...],
    ligands_before: tuple[str, ...],
    ligands_after: tuple[str, ...],
) -> None:
    missing_waters = sorted(set(waters_before) - set(waters_after))
    missing_ligands = sorted(set(ligands_before) - set(ligands_after))
    if not missing_waters and not missing_ligands:
        return
    parts = []
    if missing_waters:
        parts.append(f"waters removed: {', '.join(missing_waters)}")
    if missing_ligands:
        parts.append(f"ligands removed: {', '.join(missing_ligands)}")
    raise RuntimeError(
        "Crystallographic waters or co-crystal ligands were lost during fixing ("
        + "; ".join(parts)
        + ")."
    )

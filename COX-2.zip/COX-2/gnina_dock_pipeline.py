#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gnina_dock_pipeline.py
======================
Universal, reproducible protein-ligand docking pipeline built on open-source tools:

    RDKit  -> ligand handling, 3D embedding, bond-order perception, symmetry-corrected RMSD
    PDBFixer/OpenMM (optional) -> receptor repair + protonation
    Meeko  (optional) -> AutoDock-style PDBQT preparation
    GNINA  -> CNN-rescored docking on GPU

Designed for redocking validation (reproducing an experimental co-crystal pose) as
well as virtual screening of a compound library supplied as CSV.

Author: generated pipeline, MIT-style use.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, rdFMCS, rdMolAlign
from rdkit.Chem import rdMolDescriptors

RDLogger.DisableLog("rdApp.*")

LOG = logging.getLogger("gnina-pipeline")

# --------------------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------------------

WATER_RESNAMES = {"HOH", "WAT", "DOD", "H2O", "TIP", "TIP3", "SOL"}

# Structural ions / metals that are almost always worth keeping in the receptor.
METAL_RESNAMES = {
    "ZN", "MG", "MN", "FE", "FE2", "FES", "CA", "NA", "K", "CU", "CU1", "CO",
    "NI", "CD", "HG", "MO", "W", "V", "SR", "BA", "CS", "RB", "LI", "AL",
}

STANDARD_AA = {
    "ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE",
    "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL",
    "MSE", "SEC", "PYL", "HID", "HIE", "HIP", "CYX", "ASH", "GLH", "LYN",
}

NUCLEIC = {"DA", "DT", "DG", "DC", "DU", "A", "U", "G", "C", "T", "I"}

RCSB_LIGAND_SDF = "https://files.rcsb.org/ligands/download/{code}_ideal.sdf"
RCSB_LIGAND_CIF = "https://files.rcsb.org/ligands/download/{code}.cif"

# SD tags written by GNINA
GNINA_TAGS = [
    "minimizedAffinity",        # empirical (Vina/Vinardo) score, kcal/mol, lower = better
    "minimizedRMSD",
    "CNNscore",                 # pose quality, 0-1, higher = better
    "CNNaffinity",              # predicted pKd/pKi, higher = better
    "CNNaffinity_variance",
    "CNN_VS",                   # CNNscore * CNNaffinity (virtual-screening metric)
    "CNN_affinity",
]


# --------------------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------------------


def setup_logging(logfile: Optional[Path], verbose: bool = False) -> None:
    handlers: List[logging.Handler] = [logging.StreamHandler(sys.stdout)]
    if logfile is not None:
        logfile.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(logfile, mode="a"))
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s | %(levelname)-7s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
        force=True,
    )


def sanitize_name(name: str) -> str:
    """Make a CSV compound ID safe to use as a filename while staying recognisable."""
    s = str(name).strip()
    s = re.sub(r"[^\w\-.+]", "_", s)
    s = re.sub(r"_{2,}", "_", s).strip("_.")
    return s or "unnamed"


def run_cmd(cmd: Sequence[str], logfile: Optional[Path] = None,
            timeout: Optional[int] = None, dry_run: bool = False) -> Tuple[int, str]:
    """Run a subprocess, tee stdout+stderr into logfile, return (rc, output)."""
    printable = " ".join(str(c) for c in cmd)
    LOG.debug("CMD: %s", printable)
    if dry_run:
        print(printable)
        return 0, ""
    t0 = time.time()
    try:
        proc = subprocess.run(
            [str(c) for c in cmd],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
        )
        out, rc = proc.stdout, proc.returncode
    except subprocess.TimeoutExpired as exc:
        out = (exc.output or "") + f"\n*** TIMEOUT after {timeout}s ***\n"
        rc = 124
    except FileNotFoundError as exc:
        out, rc = f"Executable not found: {exc}", 127
    if logfile is not None:
        logfile.parent.mkdir(parents=True, exist_ok=True)
        with open(logfile, "a") as fh:
            fh.write(f"$ {printable}\n{out}\n# exit={rc} elapsed={time.time()-t0:.1f}s\n")
    return rc, out


def which_or_none(name: str) -> Optional[str]:
    return shutil.which(name)


# --------------------------------------------------------------------------------------
# Step 1/2 -- split the complex, write receptor + reference ligand PDB (with CONECT)
# --------------------------------------------------------------------------------------


@dataclass
class SplitResult:
    receptor_pdb: Path
    ligand_pdb: Optional[Path]
    ligand_resname: Optional[str]
    ligand_chain: Optional[str]
    ligand_resnum: Optional[str]
    n_receptor_atoms: int
    n_ligand_atoms: int
    conect_from_input: bool


def _parse_atom_line(line: str) -> Dict[str, object]:
    return {
        "serial": int(line[6:11]),
        "name": line[12:16].strip(),
        "altloc": line[16],
        "resname": line[17:20].strip(),
        "chain": line[21],
        "resnum": line[22:26].strip(),
        "icode": line[26],
        "x": float(line[30:38]),
        "y": float(line[38:46]),
        "z": float(line[46:54]),
        "element": line[76:78].strip().upper() if len(line) >= 78 else "",
    }


def split_complex(
    pdb_path: Path,
    out_dir: Path,
    lig_resname: Optional[str],
    lig_chain: Optional[str] = None,
    lig_resnum: Optional[str] = None,
    receptor_chains: Optional[List[str]] = None,
    keep_waters: bool = False,
    keep_metals: bool = True,
    keep_hetatms: Optional[List[str]] = None,
    model: int = 1,
    ref_pdb_name: str = "ref-co-crystal.pdb",
) -> SplitResult:
    """
    Separate the protein-ligand complex.

    * The co-crystal ligand is written to ``ref-co-crystal.pdb`` preserving the ORIGINAL
      atom serial numbers so that the CONECT records copied from the input file remain
      valid. If the input has no CONECT records for the ligand, they are regenerated
      later from the RDKit molecule (see :func:`write_conect_from_mol`).
    * Everything selected as receptor goes to ``receptor_raw.pdb``.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    keep_hetatms = {h.upper() for h in (keep_hetatms or [])}

    rec_lines: List[str] = []
    lig_lines: List[str] = []
    lig_serials: set = set()
    conect_lines: List[str] = []

    found_ligands: Dict[Tuple[str, str, str], int] = {}
    current_model = 0
    in_target_model = True

    with open(pdb_path, "r", errors="replace") as fh:
        raw = fh.readlines()

    # First pass: inventory ligand copies so we can report/choose deterministically.
    for line in raw:
        if line.startswith("HETATM"):
            a = _parse_atom_line(line)
            if a["resname"] in WATER_RESNAMES:
                continue
            key = (a["resname"], a["chain"], a["resnum"])
            found_ligands[key] = found_ligands.get(key, 0) + 1

    chosen: Optional[Tuple[str, str, str]] = None
    if lig_resname:
        cands = [k for k in found_ligands if k[0].upper() == lig_resname.upper()]
        if lig_chain:
            cands = [k for k in cands if k[1] == lig_chain]
        if lig_resnum:
            cands = [k for k in cands if k[2] == str(lig_resnum)]
        if not cands:
            avail = ", ".join(f"{k[0]}:{k[1]}:{k[2]}" for k in sorted(found_ligands))
            raise SystemExit(
                f"Ligand '{lig_resname}' (chain={lig_chain}, resnum={lig_resnum}) not found "
                f"in {pdb_path.name}.\nHETATM residues present: {avail or 'none'}"
            )
        cands.sort(key=lambda k: (k[1], int(re.sub(r"\D", "", k[2]) or 0)))
        chosen = cands[0]
        if len(cands) > 1:
            LOG.warning(
                "Multiple copies of %s found (%s). Using %s:%s:%s. "
                "Use --lig_chain/--lig_resnum to select a different one.",
                lig_resname,
                ", ".join(f"{k[1]}:{k[2]}" for k in cands),
                chosen[0], chosen[1], chosen[2],
            )
        LOG.info("Reference ligand selected: %s chain %s resnum %s",
                 chosen[0], chosen[1], chosen[2])

    # Second pass: write out atoms.
    for line in raw:
        if line.startswith("MODEL"):
            current_model += 1
            in_target_model = (current_model == model)
            continue
        if line.startswith("ENDMDL"):
            in_target_model = current_model == model
            continue
        if not in_target_model:
            continue

        if line.startswith("CONECT"):
            conect_lines.append(line)
            continue

        if not (line.startswith("ATOM") or line.startswith("HETATM")):
            continue

        a = _parse_atom_line(line)

        # Discard alternate locations other than the first / 'A'
        if a["altloc"] not in (" ", "", "A", "1"):
            continue

        key = (a["resname"], a["chain"], a["resnum"])

        # ---- ligand of interest
        if chosen is not None and key == chosen:
            lig_lines.append(line)
            lig_serials.add(a["serial"])
            continue

        # ---- receptor selection
        if receptor_chains and a["chain"] not in receptor_chains:
            continue

        resn = a["resname"].upper()
        if resn in WATER_RESNAMES:
            if keep_waters:
                rec_lines.append(line)
            continue

        if line.startswith("ATOM") or resn in STANDARD_AA or resn in NUCLEIC:
            rec_lines.append(line)
            continue

        # remaining HETATM: metals / cofactors / other ligands
        if resn in keep_hetatms:
            rec_lines.append(line)
        elif keep_metals and resn in METAL_RESNAMES:
            rec_lines.append(line)
        else:
            LOG.debug("Dropping HETATM %s %s%s", resn, a["chain"], a["resnum"])

    if not rec_lines:
        raise SystemExit("No receptor atoms selected -- check --chain / --receptor_chains.")

    receptor_pdb = out_dir / "receptor_raw.pdb"
    with open(receptor_pdb, "w") as fh:
        fh.write(f"REMARK   Receptor extracted from {pdb_path.name} by gnina_dock_pipeline\n")
        fh.writelines(rec_lines)
        fh.write("END\n")
    LOG.info("Receptor written: %s (%d atoms)", receptor_pdb, len(rec_lines))

    ligand_pdb: Optional[Path] = None
    conect_kept: List[str] = []
    if lig_lines:
        # Keep only CONECT records whose referenced serials are all part of the ligand.
        for cl in conect_lines:
            fields = [cl[i:i + 5].strip() for i in range(6, min(len(cl.rstrip("\n")), 31), 5)]
            serials = [int(f) for f in fields if f.isdigit()]
            if serials and all(s in lig_serials for s in serials):
                conect_kept.append(cl if cl.endswith("\n") else cl + "\n")

        ligand_pdb = out_dir / ref_pdb_name
        with open(ligand_pdb, "w") as fh:
            fh.write(
                f"REMARK   Co-crystal ligand {chosen[0]} chain {chosen[1]} resnum {chosen[2]}\n"
                f"REMARK   Extracted from {pdb_path.name}; original atom serials preserved\n"
            )
            fh.writelines(lig_lines)
            fh.writelines(conect_kept)
            fh.write("END\n")
        LOG.info("Reference ligand written: %s (%d atoms, %d CONECT records)",
                 ligand_pdb, len(lig_lines), len(conect_kept))
        if not conect_kept:
            LOG.warning("Input PDB carries no usable CONECT records for the ligand -- "
                        "connectivity will be regenerated from the chemical template.")

    return SplitResult(
        receptor_pdb=receptor_pdb,
        ligand_pdb=ligand_pdb,
        ligand_resname=chosen[0] if chosen else None,
        ligand_chain=chosen[1] if chosen else None,
        ligand_resnum=chosen[2] if chosen else None,
        n_receptor_atoms=len(rec_lines),
        n_ligand_atoms=len(lig_lines),
        conect_from_input=bool(conect_kept),
    )


def write_conect_from_mol(mol: Chem.Mol, pdb_path: Path, serial_offset: int = 1) -> None:
    """Rewrite a ligand PDB appending CONECT records derived from an RDKit molecule."""
    lines = [l for l in open(pdb_path).read().splitlines() if not l.startswith("CONECT")]
    lines = [l for l in lines if l.strip() != "END"]

    # Map RDKit atom index -> PDB serial, using the order the atoms appear in the file.
    atom_lines = [l for l in lines if l.startswith(("ATOM", "HETATM"))]
    serials = [int(l[6:11]) for l in atom_lines]
    heavy_idx = [a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum() > 1]
    if len(heavy_idx) != len(serials):
        LOG.warning("Atom-count mismatch when regenerating CONECT (%d mol vs %d pdb); skipping.",
                    len(heavy_idx), len(serials))
        return
    idx2serial = {ai: s for ai, s in zip(heavy_idx, serials)}

    conect: List[str] = []
    for ai in heavy_idx:
        nbrs = [idx2serial[n.GetIdx()] for n in mol.GetAtomWithIdx(ai).GetNeighbors()
                if n.GetIdx() in idx2serial]
        for i in range(0, len(nbrs), 4):
            chunk = nbrs[i:i + 4]
            conect.append("CONECT" + f"{idx2serial[ai]:>5}" + "".join(f"{n:>5}" for n in chunk))

    with open(pdb_path, "w") as fh:
        fh.write("\n".join(lines) + "\n")
        fh.write("\n".join(conect) + "\nEND\n")
    LOG.info("Regenerated %d CONECT records in %s", len(conect), pdb_path.name)


# --------------------------------------------------------------------------------------
# Step 3/4 -- reference ligand -> correct bond orders -> SDF
# --------------------------------------------------------------------------------------


def fetch_ccd_template(code: str, cache_dir: Path, offline: bool = False) -> Optional[Chem.Mol]:
    """Download the idealised SDF for a PDB chemical-component code from RCSB."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    local = cache_dir / f"{code.upper()}_ideal.sdf"
    if local.exists():
        m = Chem.MolFromMolFile(str(local))
        if m:
            LOG.info("Using cached CCD template %s", local.name)
            return m
    if offline:
        return None
    url = RCSB_LIGAND_SDF.format(code=code.upper())
    try:
        import urllib.request
        LOG.info("Fetching chemical-component template: %s", url)
        with urllib.request.urlopen(url, timeout=20) as resp:
            data = resp.read().decode("utf-8", errors="replace")
        local.write_text(data)
        m = Chem.MolFromMolFile(str(local))
        if m is None:
            LOG.warning("Downloaded CCD entry for %s could not be parsed.", code)
        return m
    except Exception as exc:  # noqa: BLE001
        LOG.warning("Could not fetch CCD template for %s (%s). "
                    "Supply --ref_smiles or --ref_template for guaranteed bond orders.",
                    code, exc)
        return None


def reference_pdb_to_mol(
    ligand_pdb: Path,
    template_smiles: Optional[str] = None,
    template_mol: Optional[Chem.Mol] = None,
    add_hydrogens: bool = True,
) -> Chem.Mol:
    """
    Read a ligand PDB and restore correct bond orders / formal charges using a template.

    Strategy (in order of reliability):
      1. explicit --ref_smiles from the user
      2. RCSB Chemical Component Dictionary ideal SDF (cached)
      3. RDKit proximity bonding only  -> single bonds, WARNING emitted
    """
    raw = Chem.MolFromPDBFile(
        str(ligand_pdb), sanitize=False, removeHs=False, proximityBonding=True
    )
    if raw is None:
        raise SystemExit(f"RDKit failed to read {ligand_pdb}")

    template: Optional[Chem.Mol] = None
    if template_smiles:
        template = Chem.MolFromSmiles(template_smiles)
        if template is None:
            raise SystemExit(f"--ref_smiles could not be parsed: {template_smiles}")
    elif template_mol is not None:
        template = template_mol

    probe = Chem.RemoveHs(raw, sanitize=False, updateExplicitCount=True)
    try:
        Chem.SanitizeMol(
            probe,
            sanitizeOps=Chem.SanitizeFlags.SANITIZE_ALL
            ^ Chem.SanitizeFlags.SANITIZE_KEKULIZE
            ^ Chem.SanitizeFlags.SANITIZE_SETAROMATICITY
            ^ Chem.SanitizeFlags.SANITIZE_PROPERTIES,
        )
    except Exception:  # noqa: BLE001
        pass

    mol: Optional[Chem.Mol] = None
    if template is not None:
        tmpl = Chem.RemoveHs(template)
        n_t = tmpl.GetNumHeavyAtoms()
        n_p = probe.GetNumHeavyAtoms()
        if n_t != n_p:
            LOG.warning(
                "Template has %d heavy atoms, extracted ligand has %d. "
                "Bond-order transfer may fail (missing/disordered atoms in the crystal?).",
                n_t, n_p,
            )
        try:
            mol = AllChem.AssignBondOrdersFromTemplate(tmpl, probe)
            LOG.info("Bond orders assigned from chemical template.")
        except Exception as exc:  # noqa: BLE001
            LOG.warning("AssignBondOrdersFromTemplate failed (%s); falling back.", exc)

    if mol is None:
        LOG.warning(
            "Falling back to proximity-perceived connectivity for the reference ligand. "
            "Bond orders will be approximate -- strongly consider passing --ref_smiles."
        )
        mol = probe
        try:
            Chem.SanitizeMol(mol)
        except Exception as exc:  # noqa: BLE001
            LOG.warning("Sanitisation of reference ligand incomplete: %s", exc)

    Chem.AssignStereochemistryFrom3D(mol)

    if add_hydrogens:
        mol = Chem.AddHs(mol, addCoords=True)
        # Relax hydrogens only, keeping heavy atoms exactly at their crystallographic positions.
        try:
            mp = AllChem.MMFFGetMoleculeProperties(mol)
            if mp is not None:
                ff = AllChem.MMFFGetMoleculeForceField(mol, mp)
                for atom in mol.GetAtoms():
                    if atom.GetAtomicNum() > 1:
                        ff.AddFixedPoint(atom.GetIdx())
                ff.Minimize(maxIts=2000)
                LOG.info("Reference ligand hydrogens optimised (heavy atoms frozen).")
        except Exception as exc:  # noqa: BLE001
            LOG.debug("H-only optimisation skipped: %s", exc)

    mol.SetProp("_Name", ligand_pdb.stem)
    return mol


# --------------------------------------------------------------------------------------
# Step 5/6 -- CSV -> 3D ligands
# --------------------------------------------------------------------------------------


@dataclass
class LigandRecord:
    cid: str
    safe_id: str
    smiles: str
    sdf: Optional[Path] = None
    status: str = "pending"
    note: str = ""
    n_confs: int = 0
    energy: Optional[float] = None
    n_rot_bonds: Optional[int] = None
    parent_id: Optional[str] = None  # set when this row is an enumerated stereoisomer
    stereo_index: Optional[int] = None


def enumerate_undefined_stereoisomers(
    mol: Chem.Mol,
    max_isomers: int = 32,
) -> List[Chem.Mol]:
    """
    Expand unassigned tetrahedral / double-bond stereo into concrete isomers.
    Already-defined stereo is left untouched (onlyUnassigned=True).
    """
    from rdkit.Chem.EnumerateStereoisomers import (
        EnumerateStereoisomers,
        StereoEnumerationOptions,
    )

    opts = StereoEnumerationOptions(
        tryEmbedding=False,
        unique=True,
        maxIsomers=max_isomers,
        onlyUnassigned=True,
    )
    isomers = list(EnumerateStereoisomers(Chem.Mol(mol), options=opts))
    if not isomers:
        return [Chem.Mol(mol)]
    return isomers


def read_compound_csv(csv_path: Path, id_col: str, smiles_col: str) -> List[LigandRecord]:
    records: List[LigandRecord] = []
    seen: Dict[str, int] = {}
    with open(csv_path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            raise SystemExit(f"{csv_path} appears to be empty.")
        cols = {c.strip().lower(): c for c in reader.fieldnames}
        idc = cols.get(id_col.strip().lower())
        smc = cols.get(smiles_col.strip().lower())
        if idc is None or smc is None:
            raise SystemExit(
                f"CSV must contain '{id_col}' and '{smiles_col}' columns. "
                f"Found: {reader.fieldnames}"
            )
        for i, row in enumerate(reader, start=2):
            cid = (row.get(idc) or "").strip()
            smi = (row.get(smc) or "").strip()
            if not smi:
                LOG.warning("Row %d: empty SMILES, skipped.", i)
                continue
            if not cid:
                cid = f"cmpd_{i-1}"
            safe = sanitize_name(cid)
            if safe in seen:
                seen[safe] += 1
                safe = f"{safe}_{seen[safe]}"
                LOG.warning("Duplicate ID '%s' -> renamed '%s'", cid, safe)
            else:
                seen[safe] = 0
            records.append(LigandRecord(cid=cid, safe_id=safe, smiles=smi))
    LOG.info("Read %d compounds from %s", len(records), csv_path.name)
    return records


def standardise_smiles(smi: str, neutralise: bool = False) -> Optional[Chem.Mol]:
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        return None
    # Keep only the largest organic fragment (strips salts / counter-ions).
    frags = Chem.GetMolFrags(mol, asMols=True, sanitizeFrags=True)
    if len(frags) > 1:
        mol = max(frags, key=lambda m: m.GetNumHeavyAtoms())
    if neutralise:
        try:
            from rdkit.Chem.MolStandardize import rdMolStandardize
            mol = rdMolStandardize.Uncharger().uncharge(mol)
        except Exception:  # noqa: BLE001
            pass
    return mol


def embed_and_minimise(
    mol: Chem.Mol,
    n_confs: int = 20,
    seed: int = 42,
    max_iters: int = 20000,
    forcefield: str = "MMFF94s",
    prune_rms: float = 0.5,
) -> Tuple[Optional[Chem.Mol], Optional[float], int, str]:
    """
    Generate 3D coordinates with ETKDGv3, minimise every conformer to tight convergence,
    and return the lowest-energy conformer as a single-conformer molecule.
    """
    mol = Chem.AddHs(mol, addCoords=False)

    params = AllChem.ETKDGv3()
    params.randomSeed = seed
    params.useSmallRingTorsions = True
    params.useMacrocycleTorsions = True
    params.enforceChirality = True
    params.pruneRmsThresh = prune_rms
    params.numThreads = 0  # all available cores
    params.maxIterations = 1000

    cids = list(AllChem.EmbedMultipleConfs(mol, numConfs=n_confs, params=params))
    if not cids:
        params.useRandomCoords = True
        cids = list(AllChem.EmbedMultipleConfs(mol, numConfs=n_confs, params=params))
    if not cids:
        return None, None, 0, "embedding failed"

    note = ""
    results = None
    if forcefield.upper().startswith("MMFF") and AllChem.MMFFHasAllMoleculeParams(mol):
        variant = "MMFF94s" if forcefield.upper() == "MMFF94S" else "MMFF94"
        results = AllChem.MMFFOptimizeMoleculeConfs(
            mol, maxIters=max_iters, mmffVariant=variant, numThreads=0
        )
        note = variant
    else:
        results = AllChem.UFFOptimizeMoleculeConfs(mol, maxIters=max_iters, numThreads=0)
        note = "UFF (MMFF parameters unavailable)"

    energies = [(e, cid, conv) for (conv, e), cid in zip(results, cids)]
    n_unconverged = sum(1 for _, _, conv in energies if conv != 0)
    if n_unconverged:
        note += f"; {n_unconverged}/{len(cids)} conformers not fully converged"

    energies.sort(key=lambda t: t[0])
    best_e, best_cid, _ = energies[0]

    out = Chem.Mol(mol)
    out.RemoveAllConformers()
    conf = Chem.Conformer(mol.GetConformer(best_cid))
    conf.SetId(0)
    out.AddConformer(conf, assignId=True)
    Chem.AssignStereochemistryFrom3D(out)
    return out, float(best_e), len(cids), note


def prepare_ligands(
    records: List[LigandRecord],
    out_dir: Path,
    n_confs: int,
    seed: int,
    max_iters: int,
    forcefield: str,
    neutralise: bool,
    overwrite: bool,
    enumerate_stereo: bool = True,
    max_stereo_isomers: int = 32,
) -> List[LigandRecord]:
    """
    Build 3D SDFs. When ``enumerate_stereo`` is True (default), ligands with
    unassigned stereocentres are expanded into up to ``max_stereo_isomers``
    concrete isomers (each docked separately as ``{id}_isoNN``).
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    prepared: List[LigandRecord] = []

    def _embed_write(rec: LigandRecord, mol: Chem.Mol, extra_note: str = "") -> LigandRecord:
        sdf_path = out_dir / f"{rec.safe_id}.sdf"
        if sdf_path.exists() and not overwrite:
            rec.sdf, rec.status, rec.note = sdf_path, "ok", "reused existing SDF"
            prepared.append(rec)
            return rec

        rec.n_rot_bonds = rdMolDescriptors.CalcNumRotatableBonds(mol)
        mol3d, energy, nconf, note = embed_and_minimise(
            mol, n_confs=n_confs, seed=seed, max_iters=max_iters, forcefield=forcefield
        )
        if mol3d is None:
            rec.status, rec.note = "failed", note
            LOG.error("[%s] 3D embedding failed", rec.cid)
            prepared.append(rec)
            return rec

        iso_smi = Chem.MolToSmiles(Chem.RemoveHs(mol3d), isomericSmiles=True)
        mol3d.SetProp("_Name", rec.cid)
        mol3d.SetProp("compound_id", rec.cid)
        if rec.parent_id:
            mol3d.SetProp("parent_id", rec.parent_id)
        mol3d.SetProp("input_smiles", rec.smiles)
        mol3d.SetProp("isomeric_smiles", iso_smi)
        mol3d.SetProp("canonical_smiles", Chem.MolToSmiles(Chem.RemoveHs(mol3d)))
        mol3d.SetProp("ff_energy_kcal_mol", f"{energy:.4f}")

        writer = Chem.SDWriter(str(sdf_path))
        writer.write(mol3d)
        writer.close()

        rec.sdf, rec.status, rec.energy, rec.n_confs = sdf_path, "ok", energy, nconf
        rec.smiles = iso_smi  # report / downstream use the concrete isomer
        rec.note = (note + (f"; {extra_note}" if extra_note else "")).strip("; ")
        LOG.info("[%s] 3D ready (%d confs, E=%.2f kcal/mol, %d rot. bonds)%s",
                 rec.cid, nconf, energy, rec.n_rot_bonds or 0,
                 f" [{extra_note}]" if extra_note else "")
        prepared.append(rec)
        return rec

    for rec in records:
        mol = standardise_smiles(rec.smiles, neutralise=neutralise)
        if mol is None:
            rec.status, rec.note = "failed", "invalid SMILES"
            LOG.error("[%s] invalid SMILES: %s", rec.cid, rec.smiles)
            prepared.append(rec)
            continue

        undefined = Chem.FindMolChiralCenters(
            mol, includeUnassigned=True, useLegacyImplementation=False
        )
        n_undef = sum(1 for _, v in undefined if v == "?")

        if enumerate_stereo:
            isomers = enumerate_undefined_stereoisomers(mol, max_isomers=max_stereo_isomers)
            if len(isomers) > 1:
                capped = len(isomers) >= max_stereo_isomers
                LOG.info(
                    "[%s] undefined stereo -> docking %d stereoisomer(s)%s"
                    "%s",
                    rec.cid, len(isomers),
                    f" ({n_undef} unassigned tetrahedral centre(s))" if n_undef else "",
                    f" [capped at --max_stereo_isomers={max_stereo_isomers}]" if capped else "",
                )
                width = max(2, len(str(len(isomers))))
                for i, iso in enumerate(isomers, start=1):
                    tag = f"iso{i:0{width}d}"
                    child = LigandRecord(
                        cid=f"{rec.cid}_{tag}",
                        safe_id=f"{rec.safe_id}_{tag}",
                        smiles=Chem.MolToSmiles(iso, isomericSmiles=True),
                        parent_id=rec.cid,
                        stereo_index=i,
                    )
                    _embed_write(
                        child, iso,
                        f"stereoisomer {i}/{len(isomers)} of {rec.cid}",
                    )
                continue
            if n_undef:
                LOG.warning(
                    "[%s] %d undefined stereocentre(s) but enumeration yielded 1 "
                    "isomer -- docking that form.",
                    rec.cid, n_undef,
                )
                _embed_write(
                    rec, isomers[0],
                    f"{n_undef} undefined stereocentre(s); single isomer after enum",
                )
                continue

        if n_undef and not enumerate_stereo:
            LOG.warning(
                "[%s] %d undefined stereocentre(s) -- one arbitrary isomer docked "
                "(default is --enumerate_stereo; pass --no_enumerate_stereo only if "
                "you want this).",
                rec.cid, n_undef,
            )
            _embed_write(rec, mol, f"{n_undef} undefined stereocentre(s); arbitrary isomer")
        else:
            _embed_write(rec, mol)

    ok = sum(1 for r in prepared if r.status == "ok")
    LOG.info("Ligand preparation: %d/%d succeeded (after stereo expansion)",
             ok, len(prepared))
    return prepared


# --------------------------------------------------------------------------------------
# Receptor preparation (repair, protonate, optional Meeko PDBQT)
# --------------------------------------------------------------------------------------


def protonate_receptor(
    receptor_pdb: Path,
    out_pdb: Path,
    method: str = "auto",
    ph: float = 7.4,
    build_missing_loops: bool = False,
    logfile: Optional[Path] = None,
) -> Tuple[Path, str]:
    """Add missing heavy atoms and hydrogens. Returns (path, method_used)."""
    if method == "none":
        shutil.copy(receptor_pdb, out_pdb)
        return out_pdb, "none"

    if method in ("auto", "pdbfixer"):
        try:
            from pdbfixer import PDBFixer
            from openmm.app import PDBFile

            LOG.info("Repairing receptor with PDBFixer (pH %.1f)...", ph)
            fixer = PDBFixer(filename=str(receptor_pdb))
            fixer.findMissingResidues()
            if not build_missing_loops:
                # Only rebuild terminal-internal gaps is risky; default = don't build loops.
                fixer.missingResidues = {}
            fixer.findNonstandardResidues()
            fixer.replaceNonstandardResidues()
            fixer.findMissingAtoms()
            fixer.addMissingAtoms()
            fixer.addMissingHydrogens(ph)
            with open(out_pdb, "w") as fh:
                PDBFile.writeFile(fixer.topology, fixer.positions, fh, keepIds=True)
            LOG.info("Receptor prepared: %s", out_pdb)
            return out_pdb, "pdbfixer"
        except Exception as exc:  # noqa: BLE001
            LOG.warning("PDBFixer unavailable/failed (%s).", exc)
            if method == "pdbfixer":
                raise SystemExit("PDBFixer requested but failed. Install with: conda install -c conda-forge pdbfixer")

    if method in ("auto", "obabel"):
        obabel = which_or_none("obabel")
        if obabel:
            LOG.info("Protonating receptor with Open Babel (pH %.1f)...", ph)
            rc, _ = run_cmd([obabel, str(receptor_pdb), "-O", str(out_pdb), "-p", str(ph)],
                            logfile=logfile)
            if rc == 0 and out_pdb.exists():
                return out_pdb, "obabel"
            LOG.warning("Open Babel protonation failed (rc=%d).", rc)

    LOG.warning("No receptor protonation performed; GNINA/OpenBabel will perceive "
                "hydrogens internally. This is usually acceptable but less controlled.")
    shutil.copy(receptor_pdb, out_pdb)
    return out_pdb, "none"


def meeko_prepare_receptor(receptor_pdb: Path, out_prefix: Path,
                           logfile: Optional[Path]) -> Optional[Path]:
    """Best-effort Meeko receptor -> PDBQT. Non-fatal on failure."""
    exe = which_or_none("mk_prepare_receptor.py") or which_or_none("mk_prepare_receptor")
    if exe is None:
        LOG.info("Meeko receptor tool not on PATH; skipping PDBQT receptor.")
        return None
    out_prefix.parent.mkdir(parents=True, exist_ok=True)
    rc, out = run_cmd([exe, "--read_pdb", str(receptor_pdb), "-o", str(out_prefix), "-p"],
                      logfile=logfile)
    pdbqt = out_prefix.with_suffix(".pdbqt")
    if rc != 0 or not pdbqt.exists():
        # older Meeko CLI signature
        rc, out = run_cmd([exe, "-i", str(receptor_pdb), "-o", str(out_prefix), "-p"],
                          logfile=logfile)
    if pdbqt.exists():
        LOG.info("Meeko receptor PDBQT written: %s", pdbqt)
        return pdbqt
    LOG.warning("Meeko receptor preparation did not produce a PDBQT "
                "(often caused by chain breaks or missing residues). "
                "Continuing with the PDB receptor, which GNINA reads natively.")
    return None


def meeko_prepare_ligand(sdf: Path, out_pdbqt: Path,
                         logfile: Optional[Path]) -> Optional[Path]:
    exe = which_or_none("mk_prepare_ligand.py") or which_or_none("mk_prepare_ligand")
    if exe is None:
        return None
    out_pdbqt.parent.mkdir(parents=True, exist_ok=True)
    rc, _ = run_cmd([exe, "-i", str(sdf), "-o", str(out_pdbqt)], logfile=logfile)
    return out_pdbqt if rc == 0 and out_pdbqt.exists() else None


# --------------------------------------------------------------------------------------
# Docking
# --------------------------------------------------------------------------------------


@dataclass
class DockConfig:
    gnina: str
    receptor: Path
    autobox_ref: Optional[Path]
    autobox_add: float
    whole_protein: bool
    exhaustiveness: int
    num_modes: int
    min_rmsd_filter: float
    cnn_scoring: str
    cnn_model: Optional[str]
    scoring: str
    seed: int
    cpu: int
    device: int
    no_gpu: bool
    pose_sort_order: str
    num_mc_saved: Optional[int]
    flexdist: Optional[float]
    extra_args: List[str] = field(default_factory=list)


def build_gnina_cmd(cfg: DockConfig, ligand: Path, out_sdf: Path,
                    log_txt: Path, atom_terms: Optional[Path] = None) -> List[str]:
    cmd: List[str] = [cfg.gnina, "-r", str(cfg.receptor), "-l", str(ligand)]

    if cfg.whole_protein or cfg.autobox_ref is None:
        cmd += ["--autobox_ligand", str(cfg.receptor)]
    else:
        cmd += ["--autobox_ligand", str(cfg.autobox_ref)]
    cmd += ["--autobox_add", str(cfg.autobox_add), "--autobox_extend", "1"]

    if cfg.flexdist is not None and cfg.autobox_ref is not None:
        cmd += ["--flexdist_ligand", str(cfg.autobox_ref), "--flexdist", str(cfg.flexdist)]

    cmd += [
        "--scoring", cfg.scoring,
        "--cnn_scoring", cfg.cnn_scoring,
        "--exhaustiveness", str(cfg.exhaustiveness),
        "--num_modes", str(cfg.num_modes),
        "--min_rmsd_filter", str(cfg.min_rmsd_filter),
        "--pose_sort_order", cfg.pose_sort_order,
        "--seed", str(cfg.seed),
        "--cpu", str(cfg.cpu),
        "-o", str(out_sdf),
        "--log", str(log_txt),
    ]
    if cfg.cnn_model:
        cmd += ["--cnn", cfg.cnn_model]
    if cfg.num_mc_saved:
        cmd += ["--num_mc_saved", str(cfg.num_mc_saved)]
    if cfg.no_gpu:
        cmd += ["--no_gpu"]
    else:
        cmd += ["--device", str(cfg.device)]
    if atom_terms is not None:
        cmd += ["--atom_terms", str(atom_terms), "--atom_term_data"]
    cmd += cfg.extra_args
    return cmd


def dock_one(cfg: DockConfig, ligand: Path, name: str, dirs: Dict[str, Path],
             overwrite: bool, timeout: Optional[int], dry_run: bool,
             write_atom_terms: bool = False) -> Dict[str, object]:
    out_sdf = dirs["poses"] / f"{name}_docked.sdf"
    log_txt = dirs["logs"] / f"{name}_gnina.log"
    cmd_log = dirs["logs"] / f"{name}_cmd.log"
    atom_terms = dirs["atom_terms"] / f"{name}_atomterms.txt" if write_atom_terms else None

    if out_sdf.exists() and not overwrite:
        LOG.info("[%s] existing pose file found -- skipping (use --overwrite to redo).", name)
        restore_pose_bond_orders(out_sdf, ligand)
        return {"status": "skipped", "pose_file": out_sdf, "log_file": log_txt, "runtime_s": 0.0}

    cmd = build_gnina_cmd(cfg, ligand, out_sdf, log_txt, atom_terms)
    (dirs["logs"] / f"{name}_command.txt").write_text(" ".join(cmd) + "\n")

    t0 = time.time()
    rc, out = run_cmd(cmd, logfile=cmd_log, timeout=timeout, dry_run=dry_run)
    dt = time.time() - t0

    if dry_run:
        return {"status": "dry-run", "pose_file": out_sdf, "log_file": log_txt, "runtime_s": 0.0}
    if rc != 0 or not out_sdf.exists():
        LOG.error("[%s] GNINA failed (rc=%d). See %s", name, rc, cmd_log)
        return {"status": f"gnina_error_rc{rc}", "pose_file": None,
                "log_file": cmd_log, "runtime_s": dt}

    restore_pose_bond_orders(out_sdf, ligand)
    LOG.info("[%s] docked in %.1f s -> %s", name, dt, out_sdf.name)
    return {"status": "ok", "pose_file": out_sdf, "log_file": log_txt, "runtime_s": dt}


def restore_pose_bond_orders(pose_sdf: Path, template_sdf: Path) -> bool:
    """
    Rewrite docked poses so bond orders match the prepared ligand SDF.

    GNINA docks via a PDBQT-like tree and used to emit aromatic bonds as single
    bonds in the output SDF. Coordinates stay from the docked poses; connectivity
    and bond orders come from the input ligand via AssignBondOrdersFromTemplate.
    """
    if not pose_sdf.exists() or not template_sdf.exists():
        return False
    try:
        tmpl = next(m for m in Chem.SDMolSupplier(str(template_sdf), removeHs=False)
                    if m is not None)
    except StopIteration:
        LOG.warning("Bond-order restore skipped for %s: empty template %s",
                    pose_sdf.name, template_sdf.name)
        return False
    try:
        Chem.SanitizeMol(tmpl)
    except Exception:  # noqa: BLE001
        pass
    tmpl_heavy = Chem.RemoveHs(Chem.Mol(tmpl))

    poses = list(Chem.SDMolSupplier(str(pose_sdf), removeHs=False, sanitize=False))
    if not poses or all(p is None for p in poses):
        return False

    tmp = pose_sdf.with_suffix(pose_sdf.suffix + ".bo.tmp")
    writer = Chem.SDWriter(str(tmp))
    # Keep 3D; do not force 2D depiction.
    writer.SetKekulize(True)
    n_ok = 0
    for pose in poses:
        if pose is None:
            continue
        props = {k: pose.GetProp(k) for k in pose.GetPropNames()
                 if k not in ("_Name",)}
        name = pose.GetProp("_Name") if pose.HasProp("_Name") else pose_sdf.stem
        try:
            probe = Chem.RemoveHs(Chem.Mol(pose), sanitize=False)
            fixed = AllChem.AssignBondOrdersFromTemplate(tmpl_heavy, probe)
            Chem.SanitizeMol(fixed)
        except Exception as exc:  # noqa: BLE001
            LOG.warning("[%s] bond-order restore failed for a pose (%s); keeping raw.",
                        pose_sdf.stem, exc)
            fixed = pose
        else:
            n_ok += 1
        fixed.SetProp("_Name", name)
        for k, v in props.items():
            try:
                fixed.SetProp(str(k), str(v))
            except Exception:  # noqa: BLE001
                pass
        writer.write(fixed)
    writer.close()
    if n_ok == 0:
        tmp.unlink(missing_ok=True)
        return False
    tmp.replace(pose_sdf)
    LOG.info("[%s] restored bond orders on %d/%d poses from %s",
             pose_sdf.stem, n_ok, sum(1 for p in poses if p is not None),
             template_sdf.name)
    return True


# --------------------------------------------------------------------------------------
# Pose parsing + RMSD
# --------------------------------------------------------------------------------------


def read_poses(sdf_gz: Path) -> List[Chem.Mol]:
    mols: List[Chem.Mol] = []
    opener = gzip.open if str(sdf_gz).endswith(".gz") else open
    try:
        with opener(str(sdf_gz), "rb") as fh:
            for m in Chem.ForwardSDMolSupplier(fh, sanitize=True, removeHs=False):
                if m is not None:
                    mols.append(m)
    except Exception as exc:  # noqa: BLE001
        LOG.error("Failed to read poses from %s: %s", sdf_gz, exc)
    return mols


def _coords(mol: Chem.Mol, idxs: Sequence[int]) -> np.ndarray:
    conf = mol.GetConformer()
    return np.array([list(conf.GetAtomPosition(i)) for i in idxs], dtype=float)


def symmetric_rmsd(probe: Chem.Mol, ref: Chem.Mol) -> Optional[float]:
    """
    Symmetry-corrected, IN-PLACE heavy-atom RMSD (no superposition).

    This is the quantity used for redocking validation: it answers 'how far is the
    docked pose from the crystallographic pose in the receptor frame?'. Note this is
    deliberately NOT GetBestRMS, which would align the two molecules first and thereby
    hide translational/rotational placement errors.
    """
    try:
        p = Chem.RemoveHs(Chem.Mol(probe))
        r = Chem.RemoveHs(Chem.Mol(ref))
        return float(rdMolAlign.CalcRMS(p, r))
    except Exception:  # noqa: BLE001
        return None


def mcs_rmsd(probe: Chem.Mol, ref: Chem.Mol, timeout: int = 20) -> Tuple[Optional[float], int]:
    """Fallback for non-identical molecules: RMSD over the maximum common substructure."""
    try:
        p = Chem.RemoveHs(Chem.Mol(probe))
        r = Chem.RemoveHs(Chem.Mol(ref))
        res = rdFMCS.FindMCS(
            [p, r],
            atomCompare=rdFMCS.AtomCompare.CompareElements,
            bondCompare=rdFMCS.BondCompare.CompareAny,
            ringMatchesRingOnly=True,
            completeRingsOnly=False,
            timeout=timeout,
        )
        if not res.smartsString or res.numAtoms < 3:
            return None, 0
        patt = Chem.MolFromSmarts(res.smartsString)
        rm = r.GetSubstructMatch(patt)
        pms = p.GetSubstructMatches(patt, uniquify=False, maxMatches=2000)
        if not rm or not pms:
            return None, 0
        ref_xyz = _coords(r, rm)
        best = min(
            float(np.sqrt(((_coords(p, m) - ref_xyz) ** 2).sum(axis=1).mean()))
            for m in pms
        )
        return best, int(res.numAtoms)
    except Exception:  # noqa: BLE001
        return None, 0


def centroid_distance(probe: Chem.Mol, ref: Chem.Mol) -> Optional[float]:
    try:
        p = Chem.RemoveHs(Chem.Mol(probe))
        r = Chem.RemoveHs(Chem.Mol(ref))
        pc = _coords(p, range(p.GetNumAtoms())).mean(axis=0)
        rc = _coords(r, range(r.GetNumAtoms())).mean(axis=0)
        return float(np.linalg.norm(pc - rc))
    except Exception:  # noqa: BLE001
        return None


def same_molecule(a: Chem.Mol, b: Chem.Mol) -> bool:
    try:
        ia = Chem.MolToInchiKey(Chem.RemoveHs(Chem.Mol(a))).split("-")[0]
        ib = Chem.MolToInchiKey(Chem.RemoveHs(Chem.Mol(b))).split("-")[0]
        return bool(ia) and ia == ib
    except Exception:  # noqa: BLE001
        return False


def get_float_prop(mol: Chem.Mol, key: str) -> Optional[float]:
    if mol.HasProp(key):
        try:
            return float(mol.GetProp(key))
        except ValueError:
            return None
    return None


def analyse_poses(pose_file: Path, ref_mol: Optional[Chem.Mol]) -> Dict[str, object]:
    """Extract scores for the top pose and RMSD statistics across all poses."""
    poses = read_poses(pose_file)
    if not poses:
        return {"n_poses": 0}

    top = poses[0]
    res: Dict[str, object] = {
        "n_poses": len(poses),
        "CNNscore": get_float_prop(top, "CNNscore"),
        "CNNaffinity": get_float_prop(top, "CNNaffinity"),
        "CNNaffinity_variance": get_float_prop(top, "CNNaffinity_variance"),
        "CNN_VS": get_float_prop(top, "CNN_VS"),
        "minimizedAffinity_kcal_mol": get_float_prop(top, "minimizedAffinity"),
    }

    if ref_mol is None:
        res.update({"RMSD_top_pose": "NA", "RMSD_best_pose": "NA",
                    "RMSD_best_pose_rank": "NA", "RMSD_type": "NA",
                    "MCS_atoms": "NA", "centroid_dist_A": "NA"})
        return res

    identical = same_molecule(top, ref_mol)
    rmsds: List[Optional[float]] = []
    mcs_n = 0
    for p in poses:
        if identical:
            r = symmetric_rmsd(p, ref_mol)
        else:
            r, mcs_n = mcs_rmsd(p, ref_mol)
        rmsds.append(r)

    valid = [(r, i) for i, r in enumerate(rmsds) if r is not None]
    res["RMSD_type"] = "exact_symmetry_corrected" if identical else "MCS_based"
    res["MCS_atoms"] = "NA" if identical else mcs_n
    res["centroid_dist_A"] = centroid_distance(top, ref_mol)
    if valid:
        res["RMSD_top_pose"] = rmsds[0] if rmsds[0] is not None else "NA"
        best_r, best_i = min(valid, key=lambda t: t[0])
        res["RMSD_best_pose"] = best_r
        res["RMSD_best_pose_rank"] = best_i + 1
        res["all_pose_RMSD"] = ";".join("NA" if r is None else f"{r:.3f}" for r in rmsds)
    else:
        res.update({"RMSD_top_pose": "NA", "RMSD_best_pose": "NA", "RMSD_best_pose_rank": "NA"})
    return res


# --------------------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------------------


def make_dirs(root: Path) -> Dict[str, Path]:
    dirs = {
        "root": root,
        "prep": root / "01_preparation",
        "ligands": root / "02_ligands_3d",
        "pdbqt": root / "02_ligands_3d" / "pdbqt",
        "poses": root / "03_docking_poses",
        "logs": root / "04_logs",
        "atom_terms": root / "05_atom_terms",
        "results": root / "06_results",
        "cache": root / ".cache",
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return dirs


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="gnina_dock_pipeline.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="Universal GNINA docking pipeline (RDKit + Meeko + GNINA).",
        epilog="""
EXAMPLES
--------
# 1) Site-directed docking with redocking validation (recommended)
python gnina_dock_pipeline.py \\
    --protein 4HJO-AQ4_model.pdb --chain A --lig_id AQ4 \\
    --csv compounds_PV-S3_new.csv \\
    --out_dir results_4HJO --cpu 16 --num_poses 9 --gpu 0 \\
    --cnn_scoring refinement --exhaustiveness 32 --redock_ref

# 2) Blind / whole-protein docking (no co-crystal ligand)
python gnina_dock_pipeline.py \\
    --protein target.pdb --chain A --csv library.csv \\
    --out_dir results_blind --cpu 32 --gpu 0 \\
    --exhaustiveness 64 --cnn_scoring rescore

# 3) Maximum-accuracy pose reproduction (slow)
python gnina_dock_pipeline.py --protein 4HJO-AQ4_model.pdb --chain A --lig_id AQ4 \\
    --csv compounds_PV-S3_new.csv --out_dir results_hi \\
    --cnn_scoring refinement --exhaustiveness 64 --num_poses 20 \\
    --autobox_add 4 --n_confs 50 --redock_ref
""",
    )

    g_in = p.add_argument_group("Input")
    g_in.add_argument("--protein", required=True, type=Path,
                      help="Protein (or complex) PDB file.")
    g_in.add_argument("--chain", default=None,
                      help="Chain ID holding the ligand / receptor (e.g. A). Default: all chains.")
    g_in.add_argument("--receptor_chains", default=None,
                      help="Comma-separated chains to keep as receptor. Defaults to --chain.")
    g_in.add_argument("--lig_id", "--cocrystal_lig", dest="lig_id", default=None,
                      help="Co-crystal ligand residue name (e.g. AQ4). Omit for whole-protein docking.")
    g_in.add_argument("--lig_chain", default=None, help="Chain of the co-crystal ligand.")
    g_in.add_argument("--lig_resnum", default=None, help="Residue number of the co-crystal ligand.")
    g_in.add_argument("--csv", required=True, type=Path, help="CSV with compounds.")
    g_in.add_argument("--id_col", default="ID", help="CSV column with compound names.")
    g_in.add_argument("--smiles_col", default="Smiles", help="CSV column with SMILES.")
    g_in.add_argument("--ref_smiles", default=None,
                      help="SMILES of the co-crystal ligand (best way to guarantee bond orders).")
    g_in.add_argument("--ref_template", type=Path, default=None,
                      help="SDF/MOL file of the ideal co-crystal ligand (alternative to --ref_smiles).")
    g_in.add_argument("--offline", action="store_true",
                      help="Do not attempt to download templates from RCSB.")

    g_out = p.add_argument_group("Output")
    g_out.add_argument("--out_dir", type=Path, default=Path("docking_run"))
    g_out.add_argument("--overwrite", action="store_true",
                       help="Recompute even if outputs already exist.")
    g_out.add_argument("--atom_terms", action="store_true",
                       help="Write per-atom interaction terms for each pose.")

    g_prep = p.add_argument_group("Preparation")
    g_prep.add_argument("--protonate_receptor", choices=["auto", "pdbfixer", "obabel", "none"],
                        default="auto")
    g_prep.add_argument("--ph", type=float, default=7.4)
    g_prep.add_argument("--build_missing_loops", action="store_true",
                        help="Let PDBFixer rebuild missing loop residues (use with care).")
    g_prep.add_argument("--keep_waters", action="store_true")
    g_prep.add_argument("--drop_metals", action="store_true",
                        help="Remove metal ions from the receptor (kept by default).")
    g_prep.add_argument("--keep_hetatm", default="",
                        help="Comma-separated extra HETATM residue names to keep (cofactors).")
    g_prep.add_argument("--n_confs", type=int, default=20,
                        help="Conformers generated per ligand before picking the lowest-energy one.")
    g_prep.add_argument("--min_iters", type=int, default=20000,
                        help="Max force-field minimisation iterations per conformer.")
    g_prep.add_argument("--forcefield", choices=["MMFF94s", "MMFF94", "UFF"], default="MMFF94s")
    g_prep.add_argument("--neutralise", action="store_true",
                        help="Neutralise formal charges from the input SMILES.")
    g_prep.add_argument("--enumerate_stereo", dest="enumerate_stereo",
                        action="store_true", default=True,
                        help="Dock all stereoisomers for unassigned stereo (default: on). "
                             "2 undefined centres -> up to 4 isomers as {ID}_iso01..")
    g_prep.add_argument("--no_enumerate_stereo", dest="enumerate_stereo",
                        action="store_false",
                        help="Disable stereo enumeration; dock one arbitrary isomer.")
    g_prep.add_argument("--max_stereo_isomers", type=int, default=32,
                        help="Cap on enumerated stereoisomers per compound (default: 32).")
    g_prep.add_argument("--meeko", action="store_true",
                        help="Also generate Meeko PDBQT files for receptor and ligands.")
    g_prep.add_argument("--receptor_format", choices=["pdb", "pdbqt"], default="pdb",
                        help="Prefer PDB or PDBQT for GNINA. With --meeko, a Meeko PDBQT "
                             "is always preferred when produced (avoids RDKit Gasteiger NaNs "
                             "on proteins).")

    g_dock = p.add_argument_group("Docking")
    g_dock.add_argument("--gnina", default="/home/apps/gnina.cuda12.8.static",
                        help="Path to the GNINA executable.")
    g_dock.add_argument("--exhaustiveness", type=int, default=32)
    g_dock.add_argument("--num_poses", type=int, default=9, help="GNINA --num_modes.")
    g_dock.add_argument("--min_rmsd_filter", type=float, default=1.0)
    g_dock.add_argument("--autobox_add", type=float, default=4.0,
                        help="Buffer (A) around the reference ligand defining the box.")
    g_dock.add_argument("--cnn_scoring", choices=["none", "rescore", "refinement", "all"],
                        default="rescore")
    g_dock.add_argument("--cnn", dest="cnn_model", default=None,
                        help="Built-in CNN model or PREFIX_ensemble (default: GNINA's ensemble).")
    g_dock.add_argument("--scoring", default="default",
                        choices=["default", "vina", "vinardo", "ad4_scoring",
                                 "dkoes_scoring", "dkoes_fast"],
                        help="Empirical scoring function. 'default' lets GNINA decide (vina).")
    g_dock.add_argument("--pose_sort_order", choices=["CNNscore", "CNNaffinity", "Energy"],
                        default="CNNscore")
    g_dock.add_argument("--num_mc_saved", type=int, default=None)
    g_dock.add_argument("--flexdist", type=float, default=None,
                        help="Enable flexible side chains within N A of the reference ligand.")
    g_dock.add_argument("--whole_protein", action="store_true",
                        help="Force blind docking over the whole receptor.")
    g_dock.add_argument("--seed", type=int, default=42)
    g_dock.add_argument("--cpu", type=int, default=max(1, os.cpu_count() or 1))
    g_dock.add_argument("--gpu", dest="device", type=int, default=0, help="GPU device index.")
    g_dock.add_argument("--no_gpu", action="store_true")
    g_dock.add_argument("--timeout", type=int, default=None,
                        help="Per-ligand timeout in seconds.")
    g_dock.add_argument("--redock_ref", action="store_true",
                        help="Also redock the extracted co-crystal ligand as a positive control.")
    g_dock.add_argument("--extra", default="",
                        help="Extra raw GNINA flags, quoted, e.g. --extra '--minimize_early_term'.")

    g_misc = p.add_argument_group("Misc")
    g_misc.add_argument("--dry_run", action="store_true", help="Print commands, do not execute.")
    g_misc.add_argument("--prep_only", action="store_true", help="Stop after preparation.")
    g_misc.add_argument("--analyse_only", action="store_true",
                        help="Skip docking, only re-parse existing pose files.")
    g_misc.add_argument("-v", "--verbose", action="store_true")

    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    dirs = make_dirs(args.out_dir)
    setup_logging(dirs["logs"] / "pipeline.log", args.verbose)

    LOG.info("=" * 78)
    LOG.info("GNINA docking pipeline")
    LOG.info("=" * 78)
    (dirs["root"] / "run_parameters.json").write_text(
        json.dumps({k: str(v) for k, v in vars(args).items()}, indent=2)
    )

    # ---- sanity checks -----------------------------------------------------------
    if not args.protein.exists():
        raise SystemExit(f"Protein file not found: {args.protein}")
    if not args.csv.exists():
        raise SystemExit(f"CSV file not found: {args.csv}")
    gnina_exe = args.gnina
    if not (Path(gnina_exe).exists() or which_or_none(gnina_exe)):
        raise SystemExit(f"GNINA executable not found: {gnina_exe}")
    if Path(gnina_exe).exists() and not os.access(gnina_exe, os.X_OK):
        raise SystemExit(f"GNINA is not executable: chmod +x {gnina_exe}")
    rc, ver = run_cmd([gnina_exe, "--version"], logfile=dirs["logs"] / "gnina_version.log")
    LOG.info("GNINA: %s", ver.strip().splitlines()[0] if ver.strip() else "version unknown")

    receptor_chains = None
    if args.receptor_chains:
        receptor_chains = [c.strip() for c in args.receptor_chains.split(",") if c.strip()]
    elif args.chain:
        receptor_chains = [c.strip() for c in args.chain.split(",") if c.strip()]

    # ---- Step 1-3: split complex --------------------------------------------------
    LOG.info("--- Step 1: splitting the complex ---")
    split = split_complex(
        pdb_path=args.protein,
        out_dir=dirs["prep"],
        lig_resname=args.lig_id,
        lig_chain=args.lig_chain or (args.chain.split(",")[0] if args.chain else None),
        lig_resnum=args.lig_resnum,
        receptor_chains=receptor_chains,
        keep_waters=args.keep_waters,
        keep_metals=not args.drop_metals,
        keep_hetatms=[h for h in args.keep_hetatm.split(",") if h.strip()],
    )

    # ---- Step 4: reference ligand -> SDF -------------------------------------------
    ref_mol: Optional[Chem.Mol] = None
    ref_sdf: Optional[Path] = None
    if split.ligand_pdb is not None:
        LOG.info("--- Step 2: reference ligand bond-order perception ---")
        template_mol = None
        if args.ref_template and args.ref_template.exists():
            template_mol = Chem.MolFromMolFile(str(args.ref_template))
        elif not args.ref_smiles:
            template_mol = fetch_ccd_template(split.ligand_resname, dirs["cache"], args.offline)

        ref_mol = reference_pdb_to_mol(
            split.ligand_pdb, template_smiles=args.ref_smiles, template_mol=template_mol
        )
        if not split.conect_from_input:
            write_conect_from_mol(ref_mol, split.ligand_pdb)

        ref_sdf = dirs["prep"] / "ref-co-crystal.sdf"
        w = Chem.SDWriter(str(ref_sdf))
        ref_mol.SetProp("source_pdb", args.protein.name)
        ref_mol.SetProp("ligand_id", split.ligand_resname or "")
        ref_mol.SetProp("canonical_smiles", Chem.MolToSmiles(Chem.RemoveHs(ref_mol)))
        w.write(ref_mol)
        w.close()
        LOG.info("Reference SDF: %s  SMILES: %s",
                 ref_sdf, Chem.MolToSmiles(Chem.RemoveHs(ref_mol)))
    else:
        LOG.info("No co-crystal ligand given -> whole-protein (blind) docking mode; "
                 "RMSD will be reported as NA.")

    # ---- Step 5: receptor preparation ----------------------------------------------
    LOG.info("--- Step 3: receptor preparation ---")
    receptor_prepared = dirs["prep"] / "receptor_prepared.pdb"
    receptor_prepared, prot_method = protonate_receptor(
        split.receptor_pdb, receptor_prepared, method=args.protonate_receptor,
        ph=args.ph, build_missing_loops=args.build_missing_loops,
        logfile=dirs["logs"] / "receptor_prep.log",
    )
    LOG.info("Receptor protonation method: %s", prot_method)

    receptor_pdbqt = None
    if args.meeko or args.receptor_format == "pdbqt":
        receptor_pdbqt = meeko_prepare_receptor(
            receptor_prepared, dirs["prep"] / "receptor_prepared",
            dirs["logs"] / "meeko_receptor.log"
        )
    receptor_for_docking = receptor_pdbqt if receptor_pdbqt else receptor_prepared
    if args.meeko and receptor_pdbqt is None:
        LOG.warning("Meeko receptor prep requested but no PDBQT produced; using PDB.")
    LOG.info("Receptor handed to GNINA: %s", receptor_for_docking.name)

    # ---- Step 6: ligand preparation -------------------------------------------------
    LOG.info("--- Step 4: ligand 3D generation ---")
    records = read_compound_csv(args.csv, args.id_col, args.smiles_col)
    records = prepare_ligands(
        records, dirs["ligands"], n_confs=args.n_confs, seed=args.seed,
        max_iters=args.min_iters, forcefield=args.forcefield,
        neutralise=args.neutralise, overwrite=args.overwrite,
        enumerate_stereo=args.enumerate_stereo,
        max_stereo_isomers=args.max_stereo_isomers,
    )
    if args.meeko:
        for rec in records:
            if rec.sdf:
                meeko_prepare_ligand(rec.sdf, dirs["pdbqt"] / f"{rec.safe_id}.pdbqt",
                                     dirs["logs"] / "meeko_ligands.log")

    if args.prep_only:
        LOG.info("--prep_only requested; stopping here.")
        return 0

    # ---- Step 7: docking -------------------------------------------------------------
    whole = args.whole_protein or ref_sdf is None
    cfg = DockConfig(
        gnina=gnina_exe,
        receptor=receptor_for_docking,
        autobox_ref=ref_sdf,
        autobox_add=args.autobox_add,
        whole_protein=whole,
        exhaustiveness=args.exhaustiveness if not whole else max(args.exhaustiveness, 64),
        num_modes=args.num_poses,
        min_rmsd_filter=args.min_rmsd_filter,
        cnn_scoring=args.cnn_scoring,
        cnn_model=args.cnn_model,
        scoring="vina" if args.scoring == "default" else args.scoring,
        seed=args.seed,
        cpu=args.cpu,
        device=args.device,
        no_gpu=args.no_gpu,
        pose_sort_order=args.pose_sort_order,
        num_mc_saved=args.num_mc_saved,
        flexdist=args.flexdist,
        extra_args=args.extra.split() if args.extra else [],
    )
    LOG.info("--- Step 5: docking (%s, cnn_scoring=%s, exhaustiveness=%d) ---",
             "whole protein" if whole else "site-directed", cfg.cnn_scoring, cfg.exhaustiveness)

    rows: List[Dict[str, object]] = []

    # positive control: redock the crystallographic ligand
    if args.redock_ref and ref_sdf is not None and not args.analyse_only:
        LOG.info("Redocking the co-crystal ligand as a positive control...")
        ctrl = dock_one(cfg, ref_sdf, "REF_redock", dirs, args.overwrite,
                        args.timeout, args.dry_run, args.atom_terms)
        if ctrl.get("pose_file") and Path(str(ctrl["pose_file"])).exists():
            stats = analyse_poses(Path(str(ctrl["pose_file"])), ref_mol)
            LOG.info("REDOCK CONTROL: top-1 RMSD = %s A | best-of-%s RMSD = %s A (rank %s)",
                     stats.get("RMSD_top_pose"), stats.get("n_poses"),
                     stats.get("RMSD_best_pose"), stats.get("RMSD_best_pose_rank"))
            row = {"ID": "REF_redock", "SMILES": Chem.MolToSmiles(Chem.RemoveHs(ref_mol)),
                   "role": "positive_control", "prep_status": "ok"}
            row.update(ctrl)
            row.update(stats)
            rows.append(row)

    for rec in records:
        if rec.status != "ok" or rec.sdf is None:
            rows.append({"ID": rec.cid, "SMILES": rec.smiles, "role": "screen",
                         "prep_status": rec.status, "status": "not_docked",
                         "note": rec.note, "n_poses": 0})
            continue

        if args.analyse_only:
            pose_file = dirs["poses"] / f"{rec.safe_id}_docked.sdf"
            dres = {"status": "ok" if pose_file.exists() else "missing",
                    "pose_file": pose_file if pose_file.exists() else None,
                    "log_file": dirs["logs"] / f"{rec.safe_id}_gnina.log", "runtime_s": ""}
        else:
            dres = dock_one(cfg, rec.sdf, rec.safe_id, dirs, args.overwrite,
                            args.timeout, args.dry_run, args.atom_terms)

        row: Dict[str, object] = {
            "ID": rec.cid,
            "safe_id": rec.safe_id,
            "parent_id": rec.parent_id or rec.cid,
            "stereo_index": rec.stereo_index if rec.stereo_index is not None else "",
            "SMILES": rec.smiles,
            "role": "screen",
            "prep_status": rec.status,
            "n_rot_bonds": rec.n_rot_bonds,
            "conformer_energy_kcal_mol": rec.energy,
            "prep_note": rec.note,
        }
        row.update(dres)
        if dres.get("pose_file") and Path(str(dres["pose_file"])).exists():
            row.update(analyse_poses(Path(str(dres["pose_file"])), ref_mol))
        rows.append(row)

    # ---- Step 8: report ----------------------------------------------------------------
    LOG.info("--- Step 6: writing report ---")
    columns = [
        "ID", "safe_id", "parent_id", "stereo_index", "SMILES", "role", "prep_status", "status",
        "CNNscore", "CNNaffinity", "CNNaffinity_variance", "CNN_VS",
        "minimizedAffinity_kcal_mol",
        "RMSD_top_pose", "RMSD_best_pose", "RMSD_best_pose_rank", "RMSD_type",
        "MCS_atoms", "centroid_dist_A", "n_poses", "all_pose_RMSD",
        "n_rot_bonds", "conformer_energy_kcal_mol", "runtime_s",
        "pose_file", "log_file", "prep_note", "note",
    ]
    report = dirs["results"] / "docking_report.csv"
    with open(report, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for r in rows:
            out = {}
            for c in columns:
                v = r.get(c, "NA")
                if v is None:
                    v = "NA"
                if isinstance(v, float):
                    v = f"{v:.4f}"
                out[c] = v
            writer.writerow(out)

    # ranked view
    def sort_key(r: Dict[str, object]) -> float:
        v = r.get("CNNaffinity")
        return -float(v) if isinstance(v, (int, float)) else 1e9

    ranked = dirs["results"] / "docking_report_ranked.csv"
    with open(report) as fh:
        data = list(csv.DictReader(fh))
    data.sort(key=lambda d: (-float(d["CNNaffinity"]) if d.get("CNNaffinity") not in ("", "NA", None) else 1e9))
    with open(ranked, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore")
        w.writeheader()
        for i, d in enumerate(data, 1):
            d["rank"] = i
            w.writerow(d)

    n_ok = sum(1 for r in rows if r.get("status") == "ok")
    LOG.info("Docked successfully: %d / %d", n_ok, len(rows))
    LOG.info("Report:        %s", report)
    LOG.info("Ranked report: %s", ranked)
    LOG.info("Done.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
